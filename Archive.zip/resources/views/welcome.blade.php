@extends('layouts.master')
 
@section('title', 'Homepage')
 

@section('content')
    <p>This is my body content.</p>
@stop