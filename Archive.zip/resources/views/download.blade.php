@extends('layouts.master')
 
@section('title', 'Homepage')
 

@section('content')
Hello
{{$file}}
@endsection