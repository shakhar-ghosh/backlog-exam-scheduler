<?php $__env->startSection('title', 'register'); ?>
 

<?php $__env->startSection('content'); ?>
    
    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="examid" value="<?php echo e($exam->id); ?>" hidden/>
        <input type="hidden" name="exam_type" value="<?php echo e($exam->exam_type); ?>"/>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Enter your name" required>
            <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
        </div>
        <div class="form-group">
            <label for="roll">Roll:</label>
            <input type="text" class="form-control" name="roll" id="roll" placeholder="Enter your roll" required>
        </div>
        <!-- <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div> -->
        <div class="form-group">
            <label for="registration">Registration no:</label>
            <input type="text" class="form-control" name="registration" id="registration" placeholder="Enter your registration" required>
        </div>
        <div class="form-group">
            <label for="course1">Course 1:</label>
            <select class="form-select form-control" name="course1" id="course1" placeholder="Select first subject" required>
                
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?> - <?php echo e($course->course_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="course2">Course 2:</label>
            <select class="form-select form-control" name="course2" id="course2" placeholder="Select second subject">
                <option value="0">None</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?> - <?php echo e($course->course_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="course3">Course 3:</label>
            <select class="form-select form-control" name="course3" id="course3" placeholder="Select third subject">
                <option value="0">None</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?> - <?php echo e($course->course_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if($exam->exam_type == 2): ?>
        
            <div class="form-group">
                <label for="course4">Course 4:</label>
                <select class="form-select form-control" name="course4" id="course4" placeholder="Select forth subject">
                    <option value="0">None</option>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?> - <?php echo e($course->course_title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="course5">Course 5:</label>
                <select class="form-select form-control" name="course5" id="course5" placeholder="Select fifth subject">
                    <option value="0">None</option>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?> - <?php echo e($course->course_title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        
        <?php endif; ?>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-scheduler/resources/views/register.blade.php ENDPATH**/ ?>