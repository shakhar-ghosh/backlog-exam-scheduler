 
<?php $__env->startSection('title', 'Schedule'); ?>
 

<?php $__env->startSection('content'); ?>
<div>
    Courses:
    <table class="table">
        <thead>
            <td>Course</td>
            <td>No. of Student(s)</td>
            <td>Students</td>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vertexcount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coursemap[$v]); ?></td>
                    <td><?php echo e($count); ?></td>
                    <td>
                            <?php $__currentLoopData = $courseStudentMap->$v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($std); ?>&nbsp;&nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<br>
<br>
<div>
    Dependencies on courses:
    <table class="table">
        <thead>
                <td>Course</td>
                <td>Dependencies</td>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vertex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coursemap[$v]); ?></td>
                    <td>
                        <?php $__currentLoopData = $edge->$v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($coursemap[$e]); ?>&nbsp;&nbsp;
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div>
    <br>
    <br>
Day wise exam: <button id="export" onclick="exportToExcel()">Export</button>
<table class="table" id="final_table">
    <thead>
        <td>Date no.</td>
        <td>Exam(s)</td>
        <td>Student(s)</td>
    </thead>
    <tbody>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td></td>
                <td></td>
</tr>
                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td></td>
                        <td><?php echo e($coursemap[$exam]); ?>&nbsp;&nbsp;</td>
                        <td>
                            <?php $__currentLoopData = $courseStudentMap->$exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($std); ?>&nbsp;&nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<script>
    function exportToExcel()
    {
        var table = $("#final_table");
          if(table && table.length){
            $(table).table2excel({
              filename: "Final Schedule" + new Date().toLocaleString().toString() + ".xls"
            });
          }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-scheduler/resources/views/schedule.blade.php ENDPATH**/ ?>