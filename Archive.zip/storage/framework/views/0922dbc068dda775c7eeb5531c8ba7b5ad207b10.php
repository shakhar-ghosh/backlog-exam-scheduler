 
<?php $__env->startSection('title', 'Course'); ?>
 

<?php $__env->startSection('content'); ?>
    <form action="/course" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="examid" value="<?php echo e($examid); ?>"/>
        <input type="hidden" name="id" value="<?php echo e($course->id); ?>"/>
        <div class="form-group">
            <label for="course_code">Course code:</label>
            <input type="text" name="course_code" class="form-control" id="course_code" value="<?php echo e($course->course_code); ?>" required>
        </div>
        <div class="form-group">
            <label for="course_title">Course title:</label>
            <input type="text" name="course_title" class="form-control" id="course_title" value="<?php echo e($course->course_title); ?>" required>
        </div>
        <div class="form-group">
            <label for="department">Department:</label>
            <input type="text" name="department" class="form-control" id="department" value="<?php echo e($course->department); ?>" required>
        </div>
        <div class="form-group">
            <label for="year">Year:</label>
            <input type="text" name="year" class="form-control" id="year" value="<?php echo e($course->year); ?>" required>
        </div>
        <?php if($course->id==0): ?>
            <button type="submit" name="submit" value="create" class="btn btn-primary">Create Course</button>
        <?php else: ?>
            <button type="submit" name="submit" value="update" class="btn btn-success">Update Course</button>
            <button type="submit" name="submit" value="delete" class="btn btn-danger">Delete Course</button>
        <?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/course.blade.php ENDPATH**/ ?>