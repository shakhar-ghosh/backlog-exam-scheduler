 
<?php $__env->startSection('title', 'Short Semester Registration Success'); ?>
 

<?php $__env->startSection('content'); ?>
<div>
    Registration for short semester was successful. 
    <div class="row">
        <div class="col-md-4">Name:</div>
        <div class="col-md-8"><?php echo e($student->name); ?></div>
        <div class="col-md-4">Roll:</div>
        <div class="col-md-8"><?php echo e($student->roll); ?></div>
        <div class="col-md-4">Registration No.:</div>
        <div class="col-md-8"><?php echo e($student->registration); ?></div>
        <div class="col-md-4">Course 1:</div>
        <div class="col-md-8"><?php echo e($courses[$student->course1]); ?></div>
        <?php if($student->course2 && $student->course2>0): ?>
        <div class="col-md-4">Course 2:</div>
        <div class="col-md-8"><?php echo e($courses[$student->course2]); ?></div>
        <?php endif; ?>
        <?php if($student->course3 && $student->course3>0): ?>
        <div class="col-md-4">Course 3:</div>
        <div class="col-md-8"><?php echo e($courses[$student->course3]); ?></div>
        <?php endif; ?>
        <?php if($student->course4 && $student->course4>0): ?>
        <div class="col-md-4">Course 4:</div>
        <div class="col-md-8"><?php echo e($courses[$student->course4]); ?></div>
        <?php endif; ?>
        <?php if($student->course5 && $student->course5>0): ?>
        <div class="col-md-4">Course 5:</div>
        <div class="col-md-8"><?php echo e($courses[$student->course5]); ?></div>
        <?php endif; ?>
    </div>
    <br>
    <div class="text-warning">If you need to change any data, please contact with your course advisor.</div>
    <br>
    <button class="btn btn-primary" onclick="location.href='/'">Go to Home</button>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-scheduler/resources/views/shortregistrationpreview.blade.php ENDPATH**/ ?>