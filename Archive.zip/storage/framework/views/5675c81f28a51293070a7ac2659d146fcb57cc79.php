 
<?php $__env->startSection('title', 'Homepage'); ?>
 

<?php $__env->startSection('content'); ?>
    <?php if(count($exams) > 0): ?> 
    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <h5 class="card-header"><?php echo e($exam->exam_name); ?></h5>
        <div class="card-body">
            <h5 class="card-title">Department: <?php echo e($exam->department); ?></h5>
            <p class="card-text">Series: <?php echo e($exam->series); ?><hr/><span class="text-danger">Deadline: <?php echo e($exam->deadline); ?></span></p>
            <a href="/register/<?php echo e($exam->id); ?>" class="btn btn-primary">Register</a>
        </div>
    </div>
    <br>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <h2>No scheduled exams found. Please comeback later</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/home.blade.php ENDPATH**/ ?>