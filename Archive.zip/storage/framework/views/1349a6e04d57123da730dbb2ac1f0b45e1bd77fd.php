 
<?php $__env->startSection('title', 'Exam'); ?>
 

<?php $__env->startSection('content'); ?>
    <form action="/exams" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exam_name">Name:</label>
            <input type="text" name="exam_name" class="form-control" id="exam_name"  placeholder="Example: 1st year backlog examination 2020" value="<?php echo e($exam->exam_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="department">Department:</label>
            <input type="text" class="form-control" name="department" id="department" placeholder="Example: Computer Science &amp; Engineering" value="<?php echo e($exam->department); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="series">Series:</label>
            <input type="text" class="form-control" name="series" id="series" placeholder="Example: 19" value="<?php echo e($exam->series); ?>"required>
        </div>
        <div class="form-group">
            <label for="deadline">Deadline:</label>
            <input type="date" class="form-control" name="deadline" id="deadline" value="<?php echo e($exam->deadline); ?>" required/>
        </div>
        <div class="row">
            <div class="md-col-6">
                <label for="courseTable">Select the courses available for this exam:</label>
            </div>
            <div class="md-col-6 ml-auto">
                <a class="btn btn-success btn-sm" href="/courses/0/<?php echo e($exam->id); ?>">Add new course</a>
            </div>
        </div>
        <table id="courseTable" class="table md-col-12">
            <thead>
                <tr>
                    <td>Selected</td>
                    <td>Course Code</td>
                    <td>Course Title</td>
                    <td>Department</td>
                    <td>Year</td>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" name="assignedcourses[]" value="<?php echo e($course->id); ?>" id="course_<?php echo e($course->id); ?>" />
                        </td>
                    <td><?php echo e($course->course_code); ?></td>
                    <td><?php echo e($course->course_title); ?></td>
                    <td><?php echo e($course->department); ?></td>
                    <td><?php echo e($course->year); ?></td>
                    <td>
                        <a class="btn btn-primary btn-sm" href="/courses/<?php echo e($course->id); ?>/<?php echo e($exam->id); ?>">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if($new==true): ?>
            <button type="submit" name="submit" value="create" class="btn btn-primary">Create Exam</button>
        <?php else: ?>
            <input type="hidden" name="exam_id" value="<?php echo e($exam->id); ?>"/>
            <button type="submit" name="submit" value="update" class="btn btn-success">Update</button>
            <button type="submit" name="submit" value="delete" class="btn btn-danger">Delete</button>
        <?php endif; ?>
        
    </form>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function() {
		$("#courseTable").fancyTable({
			sortable: false,
			pagination: true,
			perPage:25,
			globalSearch:false,
            onInit:function(){
                <?php if($selected): ?>
                <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    $('#course_<?php echo e($val); ?>').prop('checked',true);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            }
		});		
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/exam.blade.php ENDPATH**/ ?>