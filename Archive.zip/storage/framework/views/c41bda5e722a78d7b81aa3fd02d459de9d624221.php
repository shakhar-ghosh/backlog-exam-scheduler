 
<?php $__env->startSection('title', 'Homepage'); ?>
 

<?php $__env->startSection('content'); ?>
Hello
<?php echo e($file); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/download.blade.php ENDPATH**/ ?>