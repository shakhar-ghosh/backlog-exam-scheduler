 
<?php $__env->startSection('title', 'Students'); ?>
 

<?php $__env->startSection('content'); ?>
<form action="/students" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="examid" value="<?php echo e($exam->id); ?>"/>
<label for="studentTable">Students that has registered for the examination:</label>
<table id="studentTable" class="table">
    <thead>
        <tr>
            <td>Roll</td>
            <td>Name</td>
            <td>Registration</td>
            <td>Course 1</td>
            <td>Course 2</td>
            <td>Course 3</td>
            <?php if($exam->exam_type == 2): ?>
                <td>Course 4</td>
                <td>Course 5</td>
            <?php endif; ?>
            <td>Verified</td>
            <td>Update</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student['roll']); ?></td>
                <td><?php echo e($student['name']); ?></td>
                <td><?php echo e($student['registration']); ?></td>
                <td><?php echo e($student['course1']); ?></td>
                <td><?php echo e($student['course2']); ?></td>
                <td><?php echo e($student['course3']); ?></td>
                <?php if($exam->exam_type == 2): ?>
                    <td><?php echo e($student['course4']); ?></td>
                    <td><?php echo e($student['course5']); ?></td>
                <?php endif; ?>
                <td>
                    <input class="form-check-input" type="checkbox" value="<?php echo e($student['id']); ?>" name="verification[]" 
                    <?php if($student["verified"]== true): ?>
                    checked
                    <?php endif; ?>
                    >
                </td>
                <td><a class="btn-sm btn-primary" role="button" href="/update-student/<?php echo e($student['id']); ?>" class="">Update</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<button class="btn-primary btn" type="submit" name="submit">Save</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-scheduler/resources/views/student.blade.php ENDPATH**/ ?>