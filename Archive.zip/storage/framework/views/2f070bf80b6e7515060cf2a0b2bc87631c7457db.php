 
<?php $__env->startSection('title', 'Schedule'); ?>
 

<?php $__env->startSection('content'); ?>
<div>
    Courses:
    <table class="table">
        <thead>
            <td>Course</td>
            <td>No. of Student(s)</td>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vertexcount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coursemap[$v]); ?></td>
                    <td><?php echo e($count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<br>
<br>
<div>
    Dependencies on courses:
    <table class="table">
        <thead>
                <td>Course</td>
                <td>Dependencies</td>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vertex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coursemap[$v]); ?></td>
                    <td>
                        <?php $__currentLoopData = $edge->$v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($coursemap[$e]); ?>&nbsp;&nbsp;
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div>
    <br>
    <br>
Day wise exam:
<table class="table">
    <thead>
        <td>Date no.</td>
        <td>Exam(s)</td>
    </thead>
    <tbody>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>
                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($coursemap[$exam]); ?>&nbsp;&nbsp;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/schedule.blade.php ENDPATH**/ ?>