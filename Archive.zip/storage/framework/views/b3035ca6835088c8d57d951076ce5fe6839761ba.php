<html>
    <head>
        <style>
            @page { margin: 80px; }
            table {
                width: 100%;
            }
            tr {
                border: solid;
                border-color: black;
            }
            td {
                border: solid;
                border-color: black;
            }
            .div-table {
                display: table;         
                width: auto;         
                background-color: #eee;         
                border: 1px solid #666666;         
                border-spacing: 5px; /* cellspacing:poor IE support for  this */
            }
            .div-table-row {
                display: table-row;
                width: auto;
                clear: both;
            }
            .div-table-col {
                float: left; /* fix for  buggy browsers */
                display: table-column;         
                width: 200px;         
                background-color: #ccc;  
            }
        </style>
    </head>
    <body>
        <div>
            <p><b>Date:</b> <?php echo e(date('d-m-Y')); ?></p>
            <p>To<br>
            Departmental head<br>
            Department of <?php echo e($exam->department); ?><br>
            Rajshahi University of Engineering &amp; Technology</p>
            <p><b>Medium:</b>&nbsp;Course advisor, <?php echo e($exam->series); ?> series, Department of <?php echo e($exam->department); ?>, RUET.</p>
            <p><b>Subject:</b>&nbsp;Permission to attend the <?php echo e($exam->exam_name); ?>.</p>
            <p>Sir,<br>
            With due respect, I am <?php echo e($student['name']); ?>, Roll no.: <?php echo e($student['roll']); ?>, Registration no.: <?php echo e($student['registration']); ?>, a regular student of your department. I want to participate in the following subjects in the upcoming <?php echo e($exam->exam_name); ?>.  </p>
            
            <p>
            <table>
                <tbody>
                    <tr>
                        <td>SL. No.</td>
                        <td>Course Code</td>
                        <td>Course Title</td>
                    </tr>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($course->course_code); ?></td>
                        <td><?php echo e($course->course_title); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </p>
            <p>
                So, I pray and hope that you will be kind enough to give me permission to participate in the above mentioned examinations in the upcoming <?php echo e($exam->exam_name); ?>.
            </p>
            <br>
            <br>
            <p>Your's faithfully</p>
            <br>
            <br>
            <br>
            <br>
            <p><?php echo e($student['name']); ?><br>
            Roll no.: <?php echo e($student['roll']); ?><br>
            Registration No.: <?php echo e($student['registration']); ?></p>
        </div>
    </body>
</html><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-exam-scheduler/resources/views/application.blade.php ENDPATH**/ ?>