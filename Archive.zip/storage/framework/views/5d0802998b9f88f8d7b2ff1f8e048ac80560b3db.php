 
<?php $__env->startSection('title', 'Homepage'); ?>
 

<?php $__env->startSection('content'); ?>

<form action="/login" method="POST">
    <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="email">Email address</label>
    <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shakhar/Documents/Code/Projects/backlog-scheduler/resources/views/login.blade.php ENDPATH**/ ?>